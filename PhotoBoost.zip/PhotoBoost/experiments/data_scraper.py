# A simple script to scrape data off of one Facebook profile.
import json
import requests
from requests.auth import HTTPDigestAuth
import os
import sys
import urllib


GRAPH_API = 'https://graph.facebook.com/v2.8/'


def main():
    assert(len(sys.argv) == 3)
    access_token = sys.argv[1]
    friendly_name =  sys.argv[2]
    photos_response = requests.get(GRAPH_API + 'me/photos?type=uploaded&limit=1000&access_token=' + access_token)
    assert(photos_response.ok)
    photos = json.loads(photos_response.content.decode('utf-8'))
    #assert(photos['paging']['cursors']['after'] == photos['paging']['cursors']['before'])
    # TODO ^^ WTF ^^
    print('Found %d photos, extracting data...' % len(photos['data']))
    dirname = './' + friendly_name
    #os.removedirs(dirname)
    os.mkdir(dirname)
    id = 1
    for pic in photos['data']:
        print("%d/%d" % (id, len(photos['data'])))
        id += 1
        pic_response = requests.get(GRAPH_API + pic['id'] + '/reactions?limit=1000&&access_token=' + access_token)
        assert(pic_response.ok)
        photo = json.loads(pic_response.content.decode('utf-8'))
        reactions = len(photo['data'])

        # Get the photo itself
        pic_response = requests.get(GRAPH_API + pic['id'] + '?fields=images&access_token=' + access_token)
        assert(pic_response.ok)
        photo = json.loads(pic_response.content.decode('utf-8'))
        urllib.request.urlretrieve(photo['images'][0]['source'], dirname + '/' + photo['id'] + '[' + str(reactions) + '].jpg')

if __name__ == "__main__":
    main()