
# coding: utf-8

# In[12]:

from sklearn import datasets, linear_model
from sklearn.linear_model import Ridge
from array import array
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import numpy as np

# delete this
dataset = [[0, 0], [1, 1], [2, 2]]
dataset2 = [0, 1, 3]

# DATASET. replace this
train_X = dataset
train_y = dataset2
test_X=[[0,1],[4,4]]
test_Y=[0,3]

#N = 3
#N_train = int(0.6 * N)
#N_verify = int(0.2 * N)
#train_X = X[:N_train]
#X_verify = X[N_train:][:N_verify]
#test_X = X[N_train + N_verify:]
#train_y = y[:N_train]
#y_verify = y[N_train:][:N_verify]
#test_Y = y[N_train + N_verify:]

# stuff

alphas=[0.00001, 0.0001, 0.001, 0.01, 0.1, 1.0, 10.0]

    
# MODEL: linear regression
def linear_reg(train_X, train_y, test_X,test_Y):
    training_errors = []
    test_errors = []
    # MODEL: linear regression
    # create the regression object
    regr = linear_model.LinearRegression()
    regr.fit(dataset,dataset2)
    predicted = regr.predict(train_X)
    error = mean_squared_error(dataset2, predicted)
    # print coefficients
    print("linear reg coeff", regr.coef_)
    training_errors.append(error)
    print("training error", training_errors)
    # R^2
    print("r^2", regr.score(train_X, train_y))
    
    # MODEL: ridge regression
def ridge_reg(train_X, train_y, test_X, test_Y, alphas):
    training_errors = []
    test_errors = []
    best_err = -1
    best_alpha = -1
    
    #in case we want random cross-valid.
    #n_samples, n_features = 3, 2
    #np.random.seed(0)
    #y = np.random.randn(n_samples)
    #X = np.random.randn(n_samples, n_features)
    #ridge = Ridge(alpha=1.0)
    #print("ridge coef",ridge.coef_)
    
    for alpha in alphas:
        reg = Ridge(alpha=alpha)
        reg.set_params(alpha=alpha).fit(train_X,train_y) 
        predicted = reg.predict(train_X)
        error = mean_squared_error(dataset2, predicted)
        training_errors.append(error)
        if best_err == -1 or error < best_err:
            best_err = error
            best_alpha = alpha
    #plot training error
    plt.plot(training_errors)
    plt.xlabel('training_error ridge')
    plt.show()
    # print the best alpha
    print("ridge alpha", best_alpha)

    
#MODEL: LASSO
def lasso_reg(train_X, train_y, test_X, test_Y, alphas):
    training_errors = []
    test_errors = []
    best_error = -1
    best_alpha = -1

    for alpha in alphas:
        regr = linear_model.Lasso()
        regr.set_params(alpha=alpha).fit(train_X,train_y)
#        score = regr.set_params(alpha=alpha).fit(train_X,train_y).score(test_X,test_Y)
        predicted = regr.predict(train_X)
        error = mean_squared_error(dataset2, predicted) 
        training_errors.append(error)
        if best_error == -1 or error<best_error:
            best_error = error
            best_alpha = alpha
    #plot errors. print the best alpha
    print("Lasso alpha", best_alpha)
    plt.plot(training_errors)
    plt.xlabel("train_errors")
    plt.plot(test_errors)
    plt.xlabel("test_errors")
    plt.show()

#cross validation


#def main():
   
#lasso_reg(train_X, train_y, test_X, test_Y, alphas)
ridge_reg(train_X, train_y, test_X, test_Y, alphas)



    

