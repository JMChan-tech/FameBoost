from django.db import models


class Person(models.Model):
    name = models.CharField(max_length=30)
    # TODO profile pic etc
    ml_model = models.BinaryField(null=True)
    feature_mapping = models.BinaryField(null=True)

    def __str__(self):
        return self.name


class Photo(models.Model):
    filename = models.CharField(max_length=300, primary_key=True)
    reactions = models.IntegerField(default=0)
    person = models.ForeignKey(Person)

    def __str__(self):
        return self.filename


class Tag(models.Model):
    name = models.CharField(max_length=60)
    photo = models.ManyToManyField(Photo)

    def __str__(self):
        return self.name


