from django.contrib import admin

from .models import Person, Photo, Tag

class PersonAdmin(admin.ModelAdmin):
    pass

admin.site.register(Person, PersonAdmin)
admin.site.register(Photo)
admin.site.register(Tag)