from sklearn.linear_model import Lasso, Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.preprocessing import StandardScaler

import numpy as np


def meanSqErr(data, expected):
    squared_errs = [pow((x - exp), 2) for x, exp in zip(data, expected)]
    return np.mean(squared_errs)


def getModel(d, e, lasso=True):
    a = pow(10, e)
    regression = Lasso(alpha=a) if lasso else Ridge(alpha=a)
    return Pipeline([
        #('standardize', StandardScaler()),
        ('polynomial', PolynomialFeatures(degree=d)),
        ('regression', regression)])


def findBestParams(X_train, y_train, X_verify, y_verify, lasso=True, d_min=2, d_max=4, e_min=-5, e_max=5):
    """ Returns a pair representing the best value for d and e. """
    best_err = -1
    res = ()

    for d in range(2, 4):
        for e in range(-5, 5):
            pipeline = getModel(d, e, lasso)
            pipeline.fit(X_train, y_train)

            err = meanSqErr(pipeline.predict(X_verify), y_verify)
            if best_err == -1 or err < best_err:
                best_err = err
                res = (d, e)

    return res


def linear_regression_model(X, y):
    N, D = X.shape
    N_train = int(0.6 * N)
    N_verify = int(0.2 * N)
    X_train = X[:N_train]
    X_verify = X[N_train:][:N_verify]
    X_test = X[N_train + N_verify:]
    y_train = y[:N_train]
    y_verify = y[N_train:][:N_verify]
    y_test = y[N_train + N_verify:]

    d_lasso, e_lasso = findBestParams(X_train, y_train, X_verify, y_verify, lasso=True)
    d_ridge, e_ridge = findBestParams(X_train, y_train, X_verify, y_verify, lasso=False)
    print("Best parameters for Lasso: d = %d, alpha = 10^%d; Ridge: d = %d, alpha = 10^%d" % \
            (d_lasso, e_lasso, d_ridge, e_ridge))
    lasso = getModel(d_lasso, e_lasso, lasso=True)
    ridge = getModel(d_ridge, e_ridge, lasso=False)

    N_train_final = int(0.8 * N)
    X_train_final = X[:N_train_final]
    y_train_final = y[:N_train_final]
    lasso.fit(X_train_final, y_train_final)
    ridge.fit(X_train_final, y_train_final)

    lasso_train = meanSqErr(lasso.predict(X_train_final), y_train_final)
    ridge_train = meanSqErr(ridge.predict(X_train_final), y_train_final)

    print("Mean Squared Error for Lasso on training data: %f; on test data: %f" %
            (lasso_train, meanSqErr(lasso.predict(X_test), y_test)))
    print("Mean Squared Error for Ridge on training data: %f; on test data: %f" %
            (ridge_train, meanSqErr(ridge.predict(X_test), y_test)))

    if lasso_train < ridge_train:
        return lasso
    return ridge
