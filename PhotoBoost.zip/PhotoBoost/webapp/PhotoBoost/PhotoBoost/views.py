import pickle as pcl
from django.shortcuts import render
from os import listdir
from os.path import isfile, join
import json
import re
import requests
import time
import random
import base64

from django.http import HttpResponse
import numpy as np

from .models import Person, Photo, Tag
from .regression import linear_regression_model


DATA_PATH = '../../data/'
# SUPER SECRET OMG!
SECRET_KEY = '8510d65295c34dd2a7d5bcc1d8d121c4'
API_URL = 'https://api.projectoxford.ai/vision/v1.0/analyze'
TEMP_NAME='Ana'


def index(request):
    return HttpResponse(render(request, 'index.html', {}))


# TODO merge templates
def upload(request):
    return HttpResponse(render(request, 'upload.html', {}))


def predict(request):
    person = Person.objects.get(name=TEMP_NAME)
    model = pcl.loads(person.ml_model)
    feature_id = pcl.loads(person.feature_mapping)

    best = 0
    best_img = ''
    ys = []
    ids = []

    for img_id, f in request.FILES.items():
        if not f:
            continue
        img = f.read()
        ids.append(img_id)
        features = _get_features(img=img)
        # Construct input vector.
        x = np.zeros(len(feature_id))
        for feat in features:
            if feat in feature_id:
                x[feature_id[feat]] = 1
        print(x)
        y = model.predict(x.reshape(1, -1))
        ys.append(y[0])
        print(y)
        if y[0] > best:
            print(best)
            best = y[0]
            best_img = img_id

        with open('static/' + str(img_id) + '.jpg', 'wb+') as dst:
            dst.write(img)

    context = {}
    for i in range(0, len(ids)):
        if ids[i] != best_img:
            context['other' + str(i + 1)] = '../static/' + ids[i] + '.jpg'

    for i in range(0, len(ys)):
        if ys[i] != best:
            context['score' + str(i + 1)] = ys[i]

    context['best_img'] = '../static/' + best_img + '.jpg'
    context['score'] = best

    return HttpResponse(render(request, 'predict.html', context))


def _get_features(file_path=None, img=None):
    if not img:
        with open(file_path, 'rb') as img_file:
            img = img_file.read()

    ms_features = {}
    while 'tags' not in ms_features:
        res = requests.post(url=API_URL + '?visualFeatures=Tags,Faces,Color&details=Celebrities',
                            data=img,
                            headers={
                                'Content-Type': 'application/octet-stream',
                                'Ocp-Apim-Subscription-Key': SECRET_KEY,
                            })

        ms_features = json.loads(res.text)
        if 'tags' not in ms_features:
            print('Rate limit... Sleeping...')
            time.sleep(30)

    # Skip all other features for now, only care about the tags
    return [feat['name'] for feat in ms_features['tags']]


def learn(request):
    # Hardcoded for now.
    person = Person.objects.get(name=TEMP_NAME)

    person_dir = join(DATA_PATH, person.name)

    features = dict()
    # List photos for person.
    photos_listing = [f for f in listdir(person_dir) if isfile(join(person_dir, f)) and f != '.directory']
    photos_listing = photos_listing[: int(0.25 * len(photos_listing))]
    random.shuffle(photos_listing)
    total = len(photos_listing)
    curr = 1

    for f in photos_listing:
        print("%d/%d" % (curr, total))
        curr += 1
        f_path = join(person_dir, f)

        # Get the number of reactions.
        m = re.search('\d+\[(\d+)\]\.\w+', f)
        features_list = []

        if not Photo.objects.filter(filename=f):
            photo = Photo(filename=f, reactions=m.group(1), person=person)
            photo.save()

            # Extract features from a photo.
            features_list = _get_features(f_path)
            for feat in features_list:
                print('Tagging %s' % feat)
                tag = Tag.objects.get_or_create(name=feat)[0]
                tag.photo.add(photo)
                tag.save()
        else:
            photo = Photo.objects.get(filename=f)
            tags = Tag.objects.filter(photo=photo)
            features_list = [tag.name for tag in tags]

        print(f, features_list)
        features[f] = (features_list)

    # Prepare a map of all features.
    current_id = 0
    feature_id = {}
    for _, (features_list) in features.items():
        for feat in features_list:
            if feat not in feature_id:
                feature_id[feat] = current_id
                current_id += 1

    # Create input for ML.
    N = len(features)
    D = current_id
    X = np.zeros((N, D))
    y = np.zeros(N)

    current_id = 0
    for f in photos_listing:
        m = re.search('\d+\[(\d+)\]\.\w+', f)
        y[current_id] = m.group(1)
        for feat in features[f]:
            X[current_id][feature_id[feat]] = 1
        current_id += 1

    print(X)
    print(y)
    print(X.shape)

    # Teach model.
    # IF YOU WANT TO CHANGE THE MODEL, PLUG IT HERE!
    # IT HAS TO BE A CLASS THAT HAS A 'predict' METHOD!
    model = linear_regression_model(X, y)

    person.ml_model = pcl.dumps(model)
    person.feature_mapping = pcl.dumps(feature_id)
    person.save()

    return HttpResponse('Learning...')